X ARENA (game space + floating panel)
1. Upload XArena.zip ke repo GitHub (root repo).
2. Tab Actions -> Build APK -> Run workflow. APK ada di Artifacts: XArena-APK.
3. Install, buka X Arena, izinkan "tampil di atas aplikasi lain" (dan izin lain di menu titik tiga > Izin aplikasi).
Panel melayang: geser dari garis di tepi layar saat game berjalan. Mode: Power Saving (hijau), Balanced (biru), Performance (oranye-kuning).
